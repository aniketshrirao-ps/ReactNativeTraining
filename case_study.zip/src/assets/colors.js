export const PrimaryColor = '#1770f2';
export const TextBoxBgColor ='#e2e2e2';
