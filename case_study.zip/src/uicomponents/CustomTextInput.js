import { TextInput, View } from "react-native"
import styles from "../styles/style";

const CustomTextInput = (props) => {
    return (
        <View>
            <TextInput style={styles.textBox}
                placeholder={props.placeholder}
                onChangeText={props.onChangeText}
                textContentType={props.textContentType}
            />
        </View> 
    )
}

export default CustomTextInput;