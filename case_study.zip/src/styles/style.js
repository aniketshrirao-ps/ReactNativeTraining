import { StyleSheet } from "react-native";
import { PrimaryColor, TextBoxBgColor } from "../assets/colors";

const styles = StyleSheet.create(
    {
        main: { 
            flex: 1, 
            flexDirection: 'column', 
            alignItems: 'center', 
            justifyContent: 'center',
            
        },

        titleStyle: {
            color: 'black',
            fontSize: 24,
            fontWeight: 'bold',
            textAlign: 'center',
            marginBottom: 20
        },

        textBoxView: {
            margin: 30
        },

        textBox: {
            margin: 10,
            width: '100%',
            backgroundColor: TextBoxBgColor
        },

        customBtn: {
            backgroundColor: PrimaryColor,
            padding: 10,
            marginTop: 15
        },

        customBtnText: {
            textAlign: 'center',
            color: 'white',
            fontSize: 18
        },

        // customAnchor:{
        //     justifyContent: 'flex-end'
        // },

        customAnchorText: {
            color: PrimaryColor,
            fontSize: 16,
            textAlign: 'right',
            marginTop: 15
        },

        prodImage : {
            width: 20,
            height: 20
        }
    }
)

export default styles;