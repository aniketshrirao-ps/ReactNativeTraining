
import { View, Text } from "react-native";
import CustomAnchors from "../uicomponents/CustomAnchors";

const Orders = (props) => {
    console.log(props)
    return(
        <View>
            <Text>No order history found.
                <CustomAnchors text='Start shopping' 
                onPress={() => props.navigation.navigate('Products')}/>
            </Text>
        </View>
    )
}

export default Orders;