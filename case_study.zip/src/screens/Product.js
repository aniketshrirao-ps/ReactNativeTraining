import { Image, Text, View } from "react-native";
import styles from "../styles/style";
import CustomButton from "../uicomponents/CustonButton";

const Product = (props) => {
    
    return(
        <View style={{flex:1}}>
        <View style={{flexDirection: 'row', width:'100%'}}>
            <Image style={styles.prodImage} source={props.imgSrc}/>
            <Text>{props.name}</Text>
            <View style={{flexDirection:'row'}}>
                <CustomButton label='+'/>
                <Text>0</Text>
                <CustomButton label='-'/>
                
            </View>
            <Text>{props.price}</Text>
        </View>
        </View>
    )
}

export default Product;