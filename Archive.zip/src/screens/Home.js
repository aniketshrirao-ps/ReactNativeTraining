import React, {useEffect} from 'react';
import { View } from "react-native";
import Orders from "./Orders";

const Home = (props) => {
    console.log(props)
    return(
        <View>
            <Orders navigation={props.navigation}/>
        </View>
    )
}

export default Home;
