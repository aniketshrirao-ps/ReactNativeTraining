import React, {useEffect} from 'react';
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import ForgotPassword from "./ForgotPassword";
import Home from "./Home";
import Orders from "./Orders";
import Products from "./Products";
import SignIn from "./SignIn";
import SignUp from "./SignUp";

const Stack  = createNativeStackNavigator();
const transHeader = {
    headerTransparent: true,
    headerTitleStyle: {
        fontWeight: 'bold',
        color: 'black',
        fontSize: 24
    }
}
function App (){
    return(
    <NavigationContainer>
        <Stack.Navigator initialRouteName='WelcomeBack' >
            <Stack.Screen name='WelcomeBack' options={transHeader} component={SignIn}/>
            <Stack.Screen name='Welcome' component={SignUp}/>
            <Stack.Screen name="Forgot" component={ForgotPassword}/>
            <Stack.Screen name='Home' component={Home}/>
            <Stack.Screen name='Products' component={Products}/>
            <Stack.Screen name='Orders' component={Orders}/>

        </Stack.Navigator>
    </NavigationContainer>
    )
}

export default App;
