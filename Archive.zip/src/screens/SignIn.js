import React, { useEffect, useState } from "react";
import { View, Text } from "react-native";
import { PrimaryColor } from "../assets/colors";
import styles from "../styles/style";
import CustomAnchors from "../uicomponents/CustomAnchors";
import CustomTextInput from "../uicomponents/CustomTextInput";
import CustomButton from "../uicomponents/CustonButton";
// import Realm from 'realm';
let realm;
const SignIn = (props) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const userSchema = {
        name: 'Users',
        properties: {
            name: 'string',
            phone: 'string',
            email: 'string',
            password: 'string',
        },
        primaryKey: 'phone'
    }

    // useEffect(() => {
    //     console.log("loaded")
    //     realm = new Realm({
    //         path: 'CaseStudy.realm',
    //         schema: [userSchema]
    //     })
    // }, [])

    const validate = () => {
        if (username.length == 10 && password) {
            const user = realm.objects('Users').filtered('phone =', username);
            if (user.length == 1) {
                props.navigation.navigate('Home');
            } else {
                alert('No user found with given details. Please Sign up');
            }
        } else {
            alert('Please enter valid credentials. Username is you phone no.')
        }
    }
    return (
        <View style={styles.main}>
            <View>
                <Text style={styles.titleStyle}>Sign In</Text>
                <CustomTextInput placeholder='Username'
                    onChangeText={(text) => setUsername(text)} />
                <CustomTextInput placeholder='Password'
                    onChangeText={(text) => setPassword(text)}
                    textContentType='password' />
                <CustomButton
                    label='Sign In'
                    onPress={validate} />
                <CustomAnchors text='Forgot Password?'
                    onPress={() => props.navigation.navigate("Let's get you")} />
                <View style={{ marginTop: 45 }}>
                    <Text>Don't have an account?
                        <Text style={{ color: PrimaryColor }}
                            onPress={() => props.navigation.navigate('Welcome')}>
                            Sign up</Text>
                    </Text>
                </View>
            </View>
        </View>

    )
}

export default SignIn;
