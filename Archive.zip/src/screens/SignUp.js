import React, { useEffect, useState } from "react";
import { View, Text, Alert } from "react-native";
import { PrimaryColor } from "../assets/colors";
import styles from "../styles/style";
//import Realm from 'realm';
import CustomTextInput from "../uicomponents/CustomTextInput";
import CustomButton from "../uicomponents/CustonButton";
let realm;
const SignUp = (props) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('')
    const [name, setName] = useState('')
    const [phone, setPhone] = useState('')

    // useEffect(() => {
    //     realm = new Realm({ path: 'CaseStudy.realm'});
    // }, [])
    const validate = () => {
    //   console.log("email:", email, " password:", password)
      //props.navigation.navigate('')
      if(email.contains('@')){
        if(password){
            if(name){
                if(phone.length==10){
                    realm.write(() => {
                        realm.create('Users',{
                            name: name,
                            phone: phone,
                            email: email,
                            password: password
                        });
                        Alert.alert('Success','Sign up successful',
                        [{
                            text: 'Ok',
                            onPress: () => props.navigation.navigate('Welcome Back')
                        }],
                        { cancelable: false})
                    })
                }else{
                    alert("Please enter a valid phone no.")
                }
            }else{
                alert("Please enter your Name");
            }
        }else{
            alert("Please enter Password");
        }
      }else{
        alert("Please enter a valid email id")
      }
    }
    return (
        <View style={styles.main}>
            <View>
                <Text style={styles.titleStyle}>Sign Up</Text>
                <CustomTextInput placeholder='Name'
                    onChangeText={(text) => setName(text)} />
                <CustomTextInput placeholder='Phone no.'
                    onChangeText={(text) => setPhone(text)} />
                <CustomTextInput placeholder='Email'
                    onChangeText={(text) => setEmail(text)} />
                <CustomTextInput placeholder='Password'
                    onChangeText={(text) => setPassword(text)}
                    textContentType='password'/>
                <CustomButton
                    label='Sign Up'
                    onPress={validate} />

                <View style={{ marginTop: 45 }}>
                    <Text>Do you have an account?
                        <Text style={{ color: PrimaryColor }}
                            onPress={() => props.navigation.navigate('Welcome Back')}>
                            Sign In</Text>
                    </Text>
                </View>
            </View>
        </View>

    )
}

export default SignUp;
