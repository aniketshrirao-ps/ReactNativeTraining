import React, { useState } from "react";
import { View, Text } from "react-native";
import { PrimaryColor } from "../assets/colors";
import styles from "../styles/style";
import CustomAnchors from "../uicomponents/CustomAnchors";
import CustomTextInput from "../uicomponents/CustomTextInput";
import CustomButton from "../uicomponents/CustonButton";

const ForgotPassword = (props) => {
    const [email, setEmail] = useState('');

    const validate = () => {
      console.log("email:", email, " password:", password)
      //props.navigation.navigate('')
    }
    return (
        <View style={styles.main}>
            <View>
                <Text style={styles.titleStyle}>Forgot</Text>
                <CustomTextInput placeholder='Email or Phone. no'
                    onChangeText={(text) => setEmail(text)}
                    textContentType='password'/>
                <CustomButton
                    label='Reset'
                    onPress={validate} />

                <View style={{ marginTop: 45 }}>
                    <Text>Back to login
                        <Text style={{ color: PrimaryColor }}
                            onPress={() => props.navigation.navigate('Welcome Back')}>
                             Sign in</Text>
                    </Text>
                </View>
            </View>
        </View>

    )
}

export default ForgotPassword;
