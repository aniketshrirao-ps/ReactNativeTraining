import React, {useEffect} from 'react';
import { FlatList, View } from "react-native";
import Product from "./Product";

const Products = (props) => {
    const products = [
        {
        id: 1,
        name: 'Jeans',
        price: 999,
        imgSrc: require('../assets/images/jeans.jpg')
    },
        {
        id: 2,
        name: 'Tshirt',
        price: 899,
        imgSrc: require('../assets/images/tshirts.jpg')
    },
        {
        id: 3,
        name: 'Dress',
        price: 1999,
        imgSrc: require('../assets/images/dress.jpg')
    },
        {
        id: 4,
        name: 'Shoes',
        price: 1499,
        imgSrc: require('../assets/images/shoes.jpg')
    },
        {
        id: 5,
        name: 'Watch',
        price: 1999,
        imgSrc: require('../assets/images/watch.jpg')
    },
        {
        id: 6,
        name: 'Jackets',
        price: 2999,
        imgSrc: require('../assets/images/jackets.jpg')
    },
]
    return(
        <View>
            <FlatList
            data={products}
            keyExtractor={(item) => item.id}
            renderItem={({item}) => (
                <Product name={item.name} price={item.price}/>
            )}
            />
        </View>
    )
}

export default Products;
