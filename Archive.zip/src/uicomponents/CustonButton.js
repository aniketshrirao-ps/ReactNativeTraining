import React from 'react';
import { TouchableOpacity, View, Text } from "react-native"
import styles from "../styles/style";

const CustomButton = (props) => {
    return(
        <View>
            <TouchableOpacity style={styles.customBtn}
            onPress={props.onPress}
            activeOpacity={1}>
                <Text style={styles.customBtnText}>{props.label}</Text>
            </TouchableOpacity>
        </View>
    )
}

export default CustomButton;
