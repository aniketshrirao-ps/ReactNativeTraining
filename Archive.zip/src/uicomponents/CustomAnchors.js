import React from 'react';
import { View, Text } from "react-native"
import styles from "../styles/style";

const CustomAnchors = (props) => {
    return(
        <View>
            <Text style={styles.customAnchorText} onPress={props.onPress}>{props.text}</Text>
        </View>
    )
}

export default CustomAnchors;
